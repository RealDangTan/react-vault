import { useState } from "react";

/**
 * Custom hook for handling form submissions
 * Simulates an API call with a 50% success rate
 */
export const useSubmit = () => {
  const [isLoading, setLoading] = useState(false);
  const [response, setResponse] = useState(null);

  const submit = async (data) => {
    setLoading(true);
    try {
      // Simulate API call with artificial delay
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      // Simulate server response (50% success rate)
      const random = Math.random();
      if (random < 0.5) {
        throw new Error("Something went wrong");
      }
      
      setResponse({
        type: "success",
        message: `Thanks for your submission ${data.firstName}, we will get back to you shortly!`,
      });
      
      return {
        type: "success",
        message: `Thanks for your submission ${data.firstName}, we will get back to you shortly!`,
      };
      
    } catch (error) {
      setResponse({
        type: "error",
        message: "Something went wrong, please try again later!",
      });
      
      return {
        type: "error",
        message: "Something went wrong, please try again later!",
      };
      
    } finally {
      setLoading(false);
    }
  };

  return { isLoading, response, submit };
};