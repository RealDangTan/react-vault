import React from "react";
import { Avatar, Heading, VStack, Box } from "@chakra-ui/react";

const greeting = "Hello, I am Pete!";
const bio1 = "A frontend developer";
const bio2 = "specialised in React";

const LandingSection = () => {
  return (
    <Box
      backgroundColor="#18181b"
      height="100vh"
      display="flex"
      alignItems="center"
      justifyContent="center"
    >
      <VStack spacing={8}>
        <Avatar
          size="2xl"
          name="Pete"
          src="https://i.pravatar.cc/150?img=7"
        />
        <Heading as="h1" size="xl" color="white">
          {greeting}
        </Heading>
        <VStack spacing={3}>
          <Heading as="h2" size="md" color="white">
            {bio1}
          </Heading>
          <Heading as="h2" size="md" color="white">
            {bio2}
          </Heading>
        </VStack>
      </VStack>
    </Box>
  );
};

export default LandingSection;