import React from "react";
import { Box, Heading, HStack, SimpleGrid, VStack } from "@chakra-ui/react";
import Card from "./Card";

const projects = [
  {
    title: "React Space",
    description:
      "Handy tool belt to create amazing AR components in a React app, with redux integration via middleware️",
    imageSrc: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1470&q=80",
  },
  {
    title: "React Infinite Scroll",
    description:
      "A scrollable bottom sheet with virtualisation support, native animations at 60 FPS and fully implemented in React Native",
    imageSrc: "https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=1470&q=80",
  },
  {
    title: "Photo Gallery",
    description:
      "A One-stop shop for photographers to share and monetize their photos, allowing them to have a second source of income",
    imageSrc: "https://images.unsplash.com/photo-1547658719-da2b51169166?auto=format&fit=crop&w=1470&q=80",
  },
  {
    title: "Event Planner",
    description:
      "A mobile application for leisure seekers to discover unique events and activities in their city with a few taps",
    imageSrc: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=1470&q=80",
  },
];

const ProjectsSection = () => {
  return (
    <Box
      backgroundColor="gray.100"
      padding={8}
      id="projects-section"
    >
      <VStack spacing={8} maxWidth="1280px" margin="0 auto">
        <Heading as="h1" size="xl">
          Featured Projects
        </Heading>
        <SimpleGrid 
          columns={[1, 1, 2]} 
          spacing={8}
          width="100%"
        >
          {projects.map((project, index) => (
            <Card
              key={index}
              title={project.title}
              description={project.description}
              imageSrc={project.imageSrc}
            />
          ))}
        </SimpleGrid>
      </VStack>
    </Box>
  );
};

export default ProjectsSection;